module.exports = {
  databaseURL: 'https://zeus-8a110.firebaseio.com/'
};