module.exports = {
  alexaAppId: 'amzn1.ask.skill.783690e2-2502-4ad2-a9fb-13acceb04d5d',
  apiAIDeveloperAccessToken: '2041497c5a024451b023f15659a42ac2'
};